version_info = (3, 0, 6)
version = '3.0.6'
release = '3.0.6'

__version__ = release  # PEP 396
