python-gear
===========

A pure-Python asynchronous library to interface with Gearman.



